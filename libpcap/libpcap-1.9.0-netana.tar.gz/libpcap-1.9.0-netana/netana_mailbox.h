/**************************************************************************************
Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.
***************************************************************************************
$Id:  $:

Description:
 Provides functionalities to operate with the netANALYZER firmware mailbox.
**************************************************************************************/

#ifndef __NETANA_MAILBOX__H
#define __NETANA_MAILBOX__H

#ifdef _WIN32
#include <Windows.h>
#endif

#include "netana_user.h"
#include "netana_errors.h"

#ifdef __KERNEL__
  #include "OS_Includes.h"
#else
  #include <stdint.h>
#endif

#ifdef __cplusplus
  extern "C" {
#endif  /* _cplusplus */

#ifdef _MSC_VER
  #if _MSC_VER >= 1000
    #define __NETANA_PACKED_PRE
    #define __NETANA_PACKED_POST
    #pragma once
    #pragma pack(1)            /* Always align structures to 1Byte boundery */
    #ifndef STRICT             /* Check Typedefinition */
      #define STRICT
    #endif
  #endif /* _MSC_VER >= 1000 */
#endif /* _MSC_VER */

/* support for GNU compiler */
#ifdef __GNUC__
  #define __NETANA_PACKED_PRE
  #define __NETANA_PACKED_POST  __attribute__((packed))
#endif

#ifndef APIENTRY
  #define APIENTRY
#endif

/*****************************************************************************/
/*! General parameters                                                       */
/*****************************************************************************/

/*! netANALYZER mailbox commands */
#define NETANA_MBX_CMD_SET_LEDS                 0x00000001
#define NETANA_MBX_CMD_SET_TIMETICK             0x00000002
#define NETANA_MBX_CMD_SET_REFTIME_CFG          0x00000003
#define NETANA_MBX_CMD_SET_CLEARCOUNTER_CFG     0x00000004


/*****************************************************************************/
/*! NETANA_MBX_CMD_SET_LEDS parameters                                       */
/*****************************************************************************/

/*! LED SEQUENCE definitions */
#define NETANA_MBX_CMD_SET_LEDS_MAX_SEQ_LEN         300     /* attention, this must not be larger than one mailbox buffer 1556 bytes */
#define NETANA_MBX_CMD_SET_LEDS_SEQ_STEP_INTERVAL   10      /* 10x10 ms (tick count) = 100 ms led interval */

/*! LED identifier */
#define NETANA_MBX_CMD_SET_LEDS_LED_IO         0
#define NETANA_MBX_CMD_SET_LEDS_LED_SYS        1
#define NETANA_MBX_CMD_SET_LEDS_LED_STA0       2
#define NETANA_MBX_CMD_SET_LEDS_LED_STA1       3

/*! possible LED sequence colors */
#define NETANA_MBX_CMD_SET_LEDS_LED_SEQUENCE_END  0
#define NETANA_MBX_CMD_SET_LEDS_LED_OFF           1
#define NETANA_MBX_CMD_SET_LEDS_LED_GREEN         2
#define NETANA_MBX_CMD_SET_LEDS_LED_RED           3   /* ATTENTION: not usable for NETANA_MBX_CMD_SET_LEDS_LED_SYS */
#define NETANA_MBX_CMD_SET_LEDS_LED_YELLOW        4
#define NETANA_MBX_CMD_SET_LEDS_LED_ORIGINAL      5
#define NETANA_MBX_CMD_SET_LEDS_LED_LOOP          6   /* resets loop counter for all LEDs to sequence number 0 and begins again, LED sequence can only be stopped by configuring another LED sequence */

/*! defines the sequence of LED colors, each sequence step lasts 100 ms,
 * the sequence is stopped when NETANA_MBX_CMD_SET_LEDS_LED_SEQUENCE_END is reached all remaining entries must be filled up with NETANA_MBX_CMD_SET_LEDS_LED_SEQUENCE_END, the LED is switched back to internal state  */
typedef __NETANA_PACKED_PRE struct NETANA_MBX_CMD_SET_LEDS_Ttag
{
  uint32_t  ulLedId;                                         /*!< ID of the LED this blink code is applied to */
  uint8_t  ulLedState[NETANA_MBX_CMD_SET_LEDS_MAX_SEQ_LEN];  /*!< blink code definition, Attention, this must not be larger than one mailbox buffer 1552 bytes */
} __NETANA_PACKED_POST NETANA_MBX_CMD_SET_LEDS_T;

int32_t netana_custom_blink(NETANA_HANDLE hDevice, NETANA_MBX_CMD_SET_LEDS_T* ptLedBlinkCode);


/*****************************************************************************/
/*! NETANA_MBX_CMD_SET_TIMETICK parameters                                       */
/*****************************************************************************/

int32_t netana_timetick_ctrl(NETANA_HANDLE hDevice, uint32_t ulTimetickInterval);


/*****************************************************************************/
/*! NETANA_MBX_CMD_SET_REFTIME_CFG parameters                                */
/*****************************************************************************/

#define NETANA_MBX_CMD_SET_REFTIME_CFG_ONCE_AT_START   0    /* apply new firmware time once at capture start, using the ullReferenceTime of netana_start_capture() */
#define NETANA_MBX_CMD_SET_REFTIME_CFG_FREERUN         1    /* don't change reftime during netana_start_capture(), just keep present time */

int32_t netana_reftime_cfg(NETANA_HANDLE hDevice, uint32_t ulRefTimeCfg);


/*****************************************************************************/
/*! NETANA_MBX_CMD_SET_CLEARCOUNTER_CFG parameters                           */
/*****************************************************************************/

#define NETANA_MBX_CMD_SET_CLEARCOUNTER_CFG_CLEAR_AT_RESTART   0    /* clears error counters to zero on netana_start_capture() */
#define NETANA_MBX_CMD_SET_CLEARCOUNTER_CFG_NO_CLEAR           1    /* keeps counter values and continues counting on netana_start_capture() */

int32_t netana_clear_counter_cfg(NETANA_HANDLE hDevice, uint32_t ulClearCfg);


/*****************************************************************************/
/*! MAILBOX parameters and initialization function                           */
/*****************************************************************************/
typedef int32_t (APIENTRY *PFN_NETANA_GET_PACKET)( NETANA_HANDLE hDev, uint32_t ulSize, NETANA_PACKET* ptRecvPkt, uint32_t ulTimeout);
typedef int32_t (APIENTRY *PFN_NETANA_PUT_PACKET)( NETANA_HANDLE hDev, NETANA_PACKET*  ptSendPkt, uint32_t ulTimeout);

/*! Function netana_mailbox_init initializes  mailbox put and get function pointer
 *
 * \param pfnGetPacket [in]  pointer to netana_get_packet function
 * \param pfnPutPacket [in]  pointer to netana_put_packet function
 *
 * \return Returns an error code or 0 on success */
int32_t netana_mailbox_init(PFN_NETANA_GET_PACKET pfnGetPacket, PFN_NETANA_PUT_PACKET pfnPutPacket);

#ifdef _MSC_VER
  #if _MSC_VER >= 1000
    #pragma pack()            /* Always align structures to default boundary */
  #endif /* _MSC_VER >= 1000 */
#endif /* _MSC_VER */

#undef __NETANA_PACKED_PRE
#undef __NETANA_PACKED_POST

#ifdef __cplusplus
  }
#endif  /* _cplusplus */

#endif /*  __NETANA_MAILBOX__H */
