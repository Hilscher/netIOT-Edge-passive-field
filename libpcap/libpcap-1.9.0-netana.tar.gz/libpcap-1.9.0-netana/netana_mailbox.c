/**************************************************************************************
Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.
***************************************************************************************
$Id:  $:

Description:
 Provides functionalities to operate with the netANALYZER firmware mailbox.
**************************************************************************************/

#include "netana_mailbox.h"
#include <string.h>
#include <assert.h>


/*! Structure of pointers to mailbox function of netANALYZER */
typedef struct NETANA_MAILBOX_FUNCTIONS_Ttag
{
  PFN_NETANA_GET_PACKET pfnGetPacket;            /*!< Function pointerto mailbox get function of netANALYZER */
  PFN_NETANA_PUT_PACKET pfnPutPacket;            /*!< Function pointerto mailbox put function of netANALYZER */
}NETANA_MAILBOX_FUNCTIONS_T;

static NETANA_MAILBOX_FUNCTIONS_T g_tMailboxFunc;

/*! Function netana_mailbox_init initializes  mailbox put and get function pointer
 *
 * \param pfnGetPacket [in]  pointer to netana_get_packet function
 * \param pfnPutPacket [in]  pointer to netana_put_packet function
 *
 * \return Returns an error code or 0 on success */
int32_t netana_mailbox_init(PFN_NETANA_GET_PACKET pfnGetPacket, PFN_NETANA_PUT_PACKET pfnPutPacket)
{
  if (NULL == pfnGetPacket || NULL == pfnPutPacket)
    return NETANA_INVALID_PARAMETER;
  g_tMailboxFunc.pfnGetPacket = pfnGetPacket;
  g_tMailboxFunc.pfnPutPacket = pfnPutPacket;
  return NETANA_NO_ERROR;
}

/*! Blink netANALYZER LEDs with custom sequence
* Blinks the netANALYZER hardware LEDs IO, SYS, STA0, STA1
*
* \param hDevice        [in] Handle to netANALYZER device
* \param ptLedBlinkCode [in] Pointer to blink code definition according to NETANA_MBX_CMD_SET_LEDS_T structure
*
* \return Return a error code or 0 on success. */
int32_t netana_custom_blink(NETANA_HANDLE hDevice, NETANA_MBX_CMD_SET_LEDS_T* ptLedBlinkCode)
{
  int32_t   lResult = 0;
  NETANA_PACKET   tSendPkt;
  NETANA_PACKET   tRxPkt;

  if (NULL == g_tMailboxFunc.pfnGetPacket ||
      NULL == g_tMailboxFunc.pfnPutPacket)
    return NETANA_INVALID_POINTER;

  memset(&tSendPkt, 0, sizeof(tSendPkt));
  memset(&tRxPkt, 0, sizeof(tRxPkt));

  /* copy blink code to mailbox data */
  tSendPkt.tHeader.ulCmd = NETANA_MBX_CMD_SET_LEDS;
  memcpy(tSendPkt.abData, ptLedBlinkCode, sizeof(NETANA_MBX_CMD_SET_LEDS_T));
  tSendPkt.tHeader.ulLen = sizeof(NETANA_MBX_CMD_SET_LEDS_T);

  /* send request to mailbox */
  lResult = g_tMailboxFunc.pfnPutPacket(hDevice, &tSendPkt, 1000);
  if (lResult == NETANA_NO_ERROR)
  {
    /* wait for result from mailbox */
    lResult = g_tMailboxFunc.pfnGetPacket(hDevice, sizeof(tRxPkt.tHeader), &tRxPkt, 1000);
    if (lResult == NETANA_NO_ERROR)
    {
      if (tRxPkt.tHeader.ulCmd != NETANA_MBX_CMD_SET_LEDS)
      {
        /* the response does not match the request, that's bad */
        assert(0);
        lResult = NETANA_FUNCTION_FAILED;
      }
      else
      {
        /* response it ok, return status code from firmware */
        lResult = (int32_t) tRxPkt.tHeader.ulState;
      }
    }
  }

  return lResult;
}


/*! Control generation of timetick pseudo frames
* If enabled the netANALYZER firmware generates automatically timetick pseudo frames.
* This function must be called always before netana_start_capture(). The timetick value
* is not keep between different capture cycles.
*
* \param hDevice            [in] Handle to netANALYZER device
* \param ulTimetickInterval [in] Timetick interval in milliseconds, 0: no time tick frames will be generated
*
* \return Return a error code or 0 on success. */
int32_t netana_timetick_ctrl(NETANA_HANDLE hDevice, uint32_t ulTimetickInterval)
{
  int32_t   lResult = 0;
  NETANA_PACKET   tSendPkt;
  NETANA_PACKET   tRxPkt;

  if (NULL == g_tMailboxFunc.pfnGetPacket ||
      NULL == g_tMailboxFunc.pfnPutPacket)
    return NETANA_INVALID_POINTER;

  memset(&tSendPkt, 0, sizeof(tSendPkt));
  memset(&tRxPkt, 0, sizeof(tRxPkt));

  /* copy blink code to mailbox data */
  tSendPkt.tHeader.ulCmd = NETANA_MBX_CMD_SET_TIMETICK;
  memcpy(tSendPkt.abData, &ulTimetickInterval, sizeof(ulTimetickInterval));
  tSendPkt.tHeader.ulLen = sizeof(ulTimetickInterval);

  /* send request to mailbox */
  lResult = g_tMailboxFunc.pfnPutPacket(hDevice, &tSendPkt, 1000);
  if (lResult == NETANA_NO_ERROR)
  {
    /* wait for result from mailbox */
    lResult = g_tMailboxFunc.pfnGetPacket(hDevice, sizeof(tRxPkt.tHeader), &tRxPkt, 1000);
    if (lResult == NETANA_NO_ERROR)
    {
      if (tRxPkt.tHeader.ulCmd != NETANA_MBX_CMD_SET_TIMETICK)
      {
        /* the response does not match the request, that's bad */
        assert(0);
        lResult = NETANA_FUNCTION_FAILED;
      }
      else
      {
        /* response it ok, return status code from firmware */
        lResult = (int32_t) tRxPkt.tHeader.ulState;
      }
    }
  }

  return lResult;
}


/*! Control reference time behaviour
* This function controls the behaviour of setting the reference time. This is useful when time base of
* the firmware should not be changed between capture cycles (e.g. restart during capture error or
* during time synchonization).
*
* \param hDevice            [in] Handle to netANALYZER device
* \param ulRefTimeCfg       [in] Mode of reference time handling (NETANA_MBX_CMD_SET_REFTIME_CFG_ONCE_AT_START or NETANA_MBX_CMD_SET_REFTIME_CFG_FREERUN)
*
* \return Return a error code or 0 on success. */
int32_t netana_reftime_cfg(NETANA_HANDLE hDevice, uint32_t ulRefTimeCfg)
{
  int32_t   lResult = 0;
  NETANA_PACKET   tSendPkt;
  NETANA_PACKET   tRxPkt;

  if (NULL == g_tMailboxFunc.pfnGetPacket ||
      NULL == g_tMailboxFunc.pfnPutPacket)
    return NETANA_INVALID_POINTER;

  memset(&tSendPkt, 0, sizeof(tSendPkt));
  memset(&tRxPkt, 0, sizeof(tRxPkt));

  /* copy blink code to mailbox data */
  tSendPkt.tHeader.ulCmd = NETANA_MBX_CMD_SET_REFTIME_CFG;
  memcpy(tSendPkt.abData, &ulRefTimeCfg, sizeof(ulRefTimeCfg));
  tSendPkt.tHeader.ulLen = sizeof(ulRefTimeCfg);

  /* send request to mailbox */
  lResult = g_tMailboxFunc.pfnPutPacket(hDevice, &tSendPkt, 1000);
  if (lResult == NETANA_NO_ERROR)
  {
    /* wait for result from mailbox */
    lResult = g_tMailboxFunc.pfnGetPacket(hDevice, sizeof(tRxPkt.tHeader), &tRxPkt, 1000);
    if (lResult == NETANA_NO_ERROR)
    {
      if (tRxPkt.tHeader.ulCmd != NETANA_MBX_CMD_SET_REFTIME_CFG)
      {
        /* the response does not match the request, that's bad */
        assert(0);
        lResult = NETANA_FUNCTION_FAILED;
      }
      else
      {
        /* response it ok, return status code from firmware */
        lResult = (int32_t) tRxPkt.tHeader.ulState;
      }
    }
  }

  return lResult;
}


/*! Control clear counter behaviour
* This function controls the behaviour of clearing frame counters. This is useful when counters of
* the firmware should not be cleared between capture cycles (e.g. restart during capture error)
*
* \param hDevice            [in] Handle to netANALYZER device
* \param ulClearCfg         [in] Mode of counter handling (NETANA_MBX_CMD_SET_CLEARCOUNTER_CFG_CLEAR_AT_RESTART or NETANA_MBX_CMD_SET_CLEARCOUNTER_CFG_NO_CLEAR)
*
* \return Return a error code or 0 on success. */
int32_t netana_clear_counter_cfg(NETANA_HANDLE hDevice, uint32_t ulClearCfg)
{
  int32_t   lResult = 0;
  NETANA_PACKET   tSendPkt;
  NETANA_PACKET   tRxPkt;

  if (NULL == g_tMailboxFunc.pfnGetPacket ||
      NULL == g_tMailboxFunc.pfnPutPacket)
    return NETANA_INVALID_POINTER;

  memset(&tSendPkt, 0, sizeof(tSendPkt));
  memset(&tRxPkt, 0, sizeof(tRxPkt));

  /* copy blink code to mailbox data */
  tSendPkt.tHeader.ulCmd = NETANA_MBX_CMD_SET_CLEARCOUNTER_CFG;
  memcpy(tSendPkt.abData, &ulClearCfg, sizeof(ulClearCfg));
  tSendPkt.tHeader.ulLen = sizeof(ulClearCfg);

  /* send request to mailbox */
  lResult = g_tMailboxFunc.pfnPutPacket(hDevice, &tSendPkt, 1000);
  if (lResult == NETANA_NO_ERROR)
  {
    /* wait for result from mailbox */
    lResult = g_tMailboxFunc.pfnGetPacket(hDevice, sizeof(tRxPkt.tHeader), &tRxPkt, 1000);
    if (lResult == NETANA_NO_ERROR)
    {
      if (tRxPkt.tHeader.ulCmd != NETANA_MBX_CMD_SET_CLEARCOUNTER_CFG)
      {
        /* the response does not match the request, that's bad */
        assert(0);
        lResult = NETANA_FUNCTION_FAILED;
      }
      else
      {
        /* response it ok, return status code from firmware */
        lResult = (int32_t) tRxPkt.tHeader.ulState;
      }
    }
  }

  return lResult;
}
