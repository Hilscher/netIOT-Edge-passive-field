/*
 * pcap-netanalyzer.c: Packet capture interface for Hilscher netANALYZER devices.
 *
 * The functionality of this code attempts to mimic that of pcap-linux as much
 * as possible. This requires libnetana to run.
 *
 * Author: Holger Pfrommer (hpfrommer@hilscher.com)
 */

#define NETANA_SYNC   /* enable this if you want to synchronize netANALYZER's HW clock with the local Linux clock */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <sys/param.h>

#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "pcap-int.h"

#include <ctype.h>
#include <netinet/in.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include "netana_user.h"
#include "netana_errors.h"
#include "netana_mailbox.h"
#include "pcap-netana.h"

#include <queue.h>
#include <pthread.h>
#include <assert.h>



/*
 * netANALYZER specific definitions, do not change unless you know what you're doing
 */
#define NUMBER_OF_RX_PORTS    10

#define RXPORT_ETH0           0
#define RXPORT_ETH1           1
#define RXPORT_ETH2           2
#define RXPORT_ETH3           3
#define RXPORT_GPIO0          4
#define RXPORT_GPIO1          5
#define RXPORT_GPIO2          6
#define RXPORT_GPIO3          7
#define RXPORT_PSEUDOFRAMES   8
#define RXPORT_TIMETICKFRAMES 9

#define TIMEOUT_MS  100

#define SORTER_NO_DROP  0
#define SORTER_DROP     1

#define MAX_QUEUE_MEM 60000000
#define MAX_QUEUE_MEM_RECOVERY (MAX_QUEUE_MEM - 5000000)


/*
 * Private data for capturing on netANALYZER devices.
 */

 /* structure for keeping track of queue size  */
typedef struct SIZEOF_RXQUEUE_Ttag
{
  int32_t   lEntries; /* This parameter is only used for debugging purposes*/
  uint64_t  ullSizeOnHeap;
} SIZEOF_RXQUEUE_T;

typedef struct NETANA_ETH_FRAME_Ttag
{
  TAILQ_ENTRY(NETANA_ETH_FRAME_Ttag) entries;
  NETANA_FRAME_HEADER_T tHeader;
  uint8_t               abData[0];  /* this size is allocated dynamically during malloc, must be last element in this structure */
} NETANA_ETH_FRAME_T;

typedef TAILQ_HEAD(tailhead, NETANA_ETH_FRAME_Ttag) NETANA_ETH_FRAMES_LIST_T;

typedef struct RX_PORT_Ttag
{
  SIZEOF_RXQUEUE_T         tSize;
  NETANA_ETH_FRAMES_LIST_T tFrameList;
} RX_PORT_T;

typedef struct SYNC_CONFIG_Ttag
{
  uint32_t     ulSyncMode;                   /*!< Hold enum of synchronization mode */
  uint32_t     ulP;                          /*!< P factor */
  uint32_t     ulI;                          /*!< I factor */
  int64_t      llIntervall;                  /*!< resync interval in nano seconds */
  pthread_t    hSyncThread;                  /*!< sync thread ptPcap for independant cyclic resyncing of netanalyzer */
  int32_t      fRunning;                     /*!< flag indicating running state */
} SYNC_CONFIG_T;


struct NETANA_PRIVATE_T 
{
	struct pcap_stat  stat;
	int64_t           llNewestFrameTime;
  pthread_mutex_t   tGetOldestFrameLock;
  RX_PORT_T         avRxPorts[NUMBER_OF_RX_PORTS];
  uint64_t          ullMaxQueueMemOverflow;
  uint64_t          ullMaxQueueMemRecovery;
  uint64_t          ullCurrentMemOfRxQueues;
  uint8_t           fOverflowActive;
  uint32_t          ulDropCount;
  uint32_t          ulReceivedCount;
  int64_t           llLastSortedFrame; /* this stores the last timestamp of the last sorted frame, and is used for consistency check only */
  uint8_t           fSorterDropActive; /* dropping of frames from frame sorter is active so no packets between overflow and recovery can leave sorter algorithm */
  uint32_t          ulAppOverflowSrc;  /* overflow source, reported by application */
  uint32_t          ulAppOverflowActive;   /* overflow initiated by application is active */
  uint8_t           abFrameBuf[1600];
  NETANA_HANDLE     hDevice;
  int32_t           iCaptureErrorPresent;
  int32_t           iRecoverFromCaptureError;
  SYNC_CONFIG_T     tSyncConfig;
};


/*
 * forward declarations
 */

static int StartCapture(pcap_t* ptPcap);
static int ReadPacket(pcap_t *pPcapGlob, int ulCnt, pcap_handler pfnCallback, u_char* pbUser);
void StopCapture(pcap_t* ptPcap);
static int GetStats(pcap_t *pPcapGlob, struct pcap_stat *ps);

void StatusCallback(uint32_t ulCaptureState, uint32_t ulCaptureError, void* pvUser);
void DataCallback(void* pvBuffer, uint32_t ulDataSize, void* pvUser);
void* SyncThreadFunction(void* pvSyncParam);
uint32_t RecoverFromCaptureError(pcap_t* pPcapGlob);
void ChangeSizeOfRxQueue(struct NETANA_PRIVATE_T* pPriv, uint32_t ulIdx, int32_t lSizeChange);




/*
 *  interface functions to libpcap 
 */

int NetanalyzerFindalldevs(pcap_if_list_t* ptDevList, char* pbErrBuf)
{
  int32_t                                 lResult     = NETANA_NO_ERROR;
  NETANA_DRIVER_INFORMATION_T             tDriverInfo = {0};
  NETANA_MNGMT_SET_DEV_CLASS_FILTER_IN_T  tDeviceClassFilter;

  tDeviceClassFilter.ulDeviceClass = NETANA_DEV_CLASS_NANL_500 | NETANA_DEV_CLASS_NSCP_100 | NETANA_DEV_CLASS_CIFX;
  netana_mngmt_exec_cmd(NETANA_MNGMT_CMD_SET_DEV_CLASS_FILTER, &tDeviceClassFilter, sizeof(tDeviceClassFilter), NULL, 0);

  lResult = netana_driver_information(sizeof(tDriverInfo), &tDriverInfo);

  if (lResult == NETANA_NO_ERROR)
	{

		for(uint32_t ulCard = 0; ulCard < tDriverInfo.ulCardCnt; ulCard++)
		{
      NETANA_DEVICE_INFORMATION_T tDevInfo = {{0}};

      if(NETANA_NO_ERROR == netana_enum_device(ulCard, sizeof(tDevInfo), &tDevInfo)) 
      {
			  if (add_dev(ptDevList,tDevInfo.szDeviceName,0,"Hilscher netANALYZER device",pbErrBuf) == NULL)
          return -1;
      }
		}
	}
  else
  {
    return -1;
  }

  return 0;
}


pcap_t* NetanalyzerCreate(const char* pbDevice, char* pbEBuf, int* piIsOurs)
{
	const char*               pchDevName;
	pcap_t*                   pPcapGlob = NULL;
	NETANA_HANDLE             hDevice   = NULL;
  struct NETANA_PRIVATE_T*  pPriv;
  uint32_t                  ulRes;

  *piIsOurs = 0;

  pchDevName = strrchr(pbDevice, '/');
  if (pchDevName == NULL)
      pchDevName = pbDevice;

  // accept all *ANALYZER* as netANALYZER devices
  if (strstr(pchDevName, "ANALYZER") == NULL) {
      return NULL;
  }

  NETANA_MNGMT_SET_DEV_CLASS_FILTER_IN_T  tDeviceClassFilter;
  tDeviceClassFilter.ulDeviceClass = NETANA_DEV_CLASS_NANL_500 | NETANA_DEV_CLASS_NSCP_100 | NETANA_DEV_CLASS_CIFX;
  netana_mngmt_exec_cmd(NETANA_MNGMT_CMD_SET_DEV_CLASS_FILTER, &tDeviceClassFilter, sizeof(tDeviceClassFilter), NULL, 0);

  ulRes = netana_open_device((char*)pchDevName, &hDevice);
  if(ulRes == NETANA_NO_ERROR)
  {
    *piIsOurs = 1;

		pPcapGlob = pcap_create_common(pbEBuf, sizeof(struct NETANA_PRIVATE_T));
		if (pPcapGlob == NULL)
			return NULL;

    pPriv = pPcapGlob->priv;

		pPcapGlob->activate_op = StartCapture;
	  pPriv->llNewestFrameTime = 0;
    pPriv->iCaptureErrorPresent = 0;
    pPriv->iRecoverFromCaptureError = 0;
    int i;
    for (i = 0; i < NUMBER_OF_RX_PORTS; i++) {
      TAILQ_INIT(&(pPriv->avRxPorts[i].tFrameList));
      pPriv->avRxPorts[i].tSize.lEntries = 0;
      pPriv->avRxPorts[i].tSize.ullSizeOnHeap = 0;
    }
	  pPriv->ullMaxQueueMemOverflow = MAX_QUEUE_MEM;
	  pPriv->ullMaxQueueMemRecovery = MAX_QUEUE_MEM_RECOVERY;
	  pPriv->ullCurrentMemOfRxQueues = 0;
	  pPriv->fOverflowActive = 0;
	  pPriv->ulDropCount = 0;
	  pPriv->ulReceivedCount = 0;
	  pPriv->llLastSortedFrame = 0;
	  pPriv->fSorterDropActive = 0;
    pPriv->ulAppOverflowSrc = 0;
    pPriv->ulAppOverflowActive = 0;
		pPriv->hDevice = hDevice;
    pthread_mutex_init(&pPriv->tGetOldestFrameLock, NULL);

    /* sync thread  */
#ifdef NETANA_SYNC
    netana_config_pi_controller(hDevice, 16, 4);
    pPriv->tSyncConfig.fRunning = 1;
    pPriv->tSyncConfig.llIntervall = 1000*1000*1000; /* init thread interval to 1 sec */
    if(0 != pthread_create(&pPriv->tSyncConfig.hSyncThread, NULL,
                              SyncThreadFunction, pPcapGlob))
    {
      pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "could not create netANALYZER sync process\n");
      return NULL;
    }
#endif  

    /*
    * We claim that we support microsecond and nanosecond time
    * stamps.
    *
    * XXX - hardware always deliveres nanosecond resolution, 
    *       pcap driver will calculate microseconds from that if required
    */
    pPcapGlob->tstamp_precision_count = 2;
    pPcapGlob->tstamp_precision_list = malloc(2 * sizeof(u_int));
    if (pPcapGlob->tstamp_precision_list == NULL) {
      pcap_fmt_errmsg_for_errno(pbEBuf, PCAP_ERRBUF_SIZE,
          errno, "malloc");
      pcap_close(pPcapGlob);
      return NULL;
    }
    pPcapGlob->tstamp_precision_list[0] = PCAP_TSTAMP_PRECISION_MICRO;
    pPcapGlob->tstamp_precision_list[1] = PCAP_TSTAMP_PRECISION_NANO;


	}
  else
  {
    pcap_snprintf(pbEBuf, PCAP_ERRBUF_SIZE, "starting capture failed with error 0x%08x\n", ulRes);
  }

	return pPcapGlob;
}


static int StartCapture(pcap_t* ptPcap)
{
  struct NETANA_PRIVATE_T* pPriv = ptPcap->priv;

  struct timespec tTime = {0};
  clock_gettime(CLOCK_REALTIME, &tTime);
  uint64_t ullRefTime = (uint64_t)tTime.tv_sec * 1000 * 1000 * 1000 + tTime.tv_nsec;

  if(NETANA_NO_ERROR != netana_mailbox_init(netana_get_packet, netana_put_packet))
    return PCAP_ERROR;

  if(NETANA_NO_ERROR != netana_timetick_ctrl(pPriv->hDevice, 1000))
    return PCAP_ERROR;

  if(NETANA_NO_ERROR == netana_start_capture( pPriv->hDevice,
                                                        0,
                                                        0xF,
                                                        NETANA_MACMODE_ETHERNET,
                                                        ullRefTime,
                                                        StatusCallback,
                                                        DataCallback,
                                                        ptPcap))
	{
                
	  /*
	   * Turn a negative snapshot value (invalid), a snapshot value of
	   * 0 (unspecified), or a value bigger than the normal maximum
	   * value, into the maximum allowed value.
	   *e
	   * If some application really *needs* a bigger snapshot
	   * length, we should just increase MAXIMUM_SNAPLEN.
	   */
	  if (ptPcap->snapshot <= 0 || ptPcap->snapshot > MAXIMUM_SNAPLEN)
	    ptPcap->snapshot = MAXIMUM_SNAPLEN;

	  ptPcap->bufsize  = MAX_QUEUE_MEM;
    ptPcap->linktype = DLT_NETANALYZER;

	  /*
	   * "select()" and "poll()" don't work on netANALYZER queues
	   */
	  ptPcap->selectable_fd = -1;

	  ptPcap->read_op = ReadPacket;
	  ptPcap->stats_op = GetStats;
	  ptPcap->cleanup_op = StopCapture;
   	ptPcap->setfilter_op = install_bpf_program;


    pPriv->iCaptureErrorPresent = 0;
    pPriv->iRecoverFromCaptureError = 0;
	}
	else
  {
		return PCAP_ERROR;
  }

  return 0;
}


/*
 *  Read a packet from the capture queue and call the callback
 *  for each of them. Returns the number of packets handled, -1 if an
 *  error occured, or -2 if we were told to break out of the loop.
 */
static int ReadPacket(pcap_t *pPcapGlob, int ulCnt, pcap_handler pfnCallback, u_char* pbUser) 
{
  int64_t                   llFrameSaveTime   = 0;
  int64_t                   llFlushTime       = 0;
  int64_t                   llCurrentWinTime  = 0;
  int32_t                   iSmallest         = 0;
  int32_t                   iFound            = 0;
  NETANA_ETH_FRAME_T*       ptOldestFrame     = {0};
  int32_t                   iIdx               = 0;
  struct NETANA_PRIVATE_T*  pPriv = pPcapGlob->priv;

  if (pPriv->iCaptureErrorPresent == 1)
  {
    return -1;
  }

  if (pPriv->iRecoverFromCaptureError == 1) 
  {
    pPriv->iRecoverFromCaptureError = 0;
    if (RecoverFromCaptureError(pPcapGlob) != 0)
    {
      return -1;
    }
  }

  pthread_mutex_lock(&pPriv->tGetOldestFrameLock);

  /* find next frame which may be timed out */
  iFound = 0;
  iSmallest = 0;
  for (iIdx = 0; iIdx < NUMBER_OF_RX_PORTS; iIdx++)
  {
    if(!TAILQ_EMPTY(&pPriv->avRxPorts[iIdx].tFrameList))
    {
      if(!TAILQ_EMPTY(&pPriv->avRxPorts[iSmallest].tFrameList))
      {
        if (TAILQ_LAST(&(pPriv->avRxPorts[iIdx].tFrameList), tailhead)->tHeader.ullTimestamp
          <= TAILQ_LAST(&(pPriv->avRxPorts[iSmallest].tFrameList), tailhead)->tHeader.ullTimestamp )
          iSmallest = iIdx;
      }
      else
        iSmallest = iIdx;
    }
  }

  if(!TAILQ_EMPTY(&pPriv->avRxPorts[iSmallest].tFrameList))
  {
    /* check if distance to previous frame is at least timeout-periode or if no new frame was captured
        within this time */
    ptOldestFrame = TAILQ_LAST(&(pPriv->avRxPorts[iSmallest].tFrameList),tailhead);
    llFrameSaveTime = ptOldestFrame->tHeader.ullTimestamp + (TIMEOUT_MS*1000000);

    if (pPriv->llNewestFrameTime > llFrameSaveTime)
    {
      iFound = 1;
    }
  }
  pthread_mutex_unlock(&pPriv->tGetOldestFrameLock);

  if (iFound == 1)
  {
    uint32_t  ulFrameSize;
    uint32_t  ulFrameSizeOrig;
    int32_t   lSizeInQueue;
    uint32_t  ulFrameType;
    uint32_t  ulStateType;
    uint32_t  ulVersion;
    uint16_t  usPort;
    struct pcap_pkthdr   pcap_header;

    ulFrameSizeOrig = (ptOldestFrame->tHeader.ulHeader & NETANA_FRAME_HEADER_LENGTH_MSK) >> NETANA_FRAME_HEADER_LENGTH_SRT;

    if (pPcapGlob->opt.tstamp_precision == PCAP_TSTAMP_PRECISION_NANO) {
      /* nanosecond timestamp */
      pcap_header.ts.tv_sec = (long)((uint64_t)ptOldestFrame->tHeader.ullTimestamp / 1000000000ULL);
      pcap_header.ts.tv_usec = (long)((uint64_t)ptOldestFrame->tHeader.ullTimestamp - (uint64_t)pcap_header.ts.tv_sec *1000000000ULL);
    }
    else {
      /* microsecond timestamp */
      pcap_header.ts.tv_sec = (long)((uint64_t)ptOldestFrame->tHeader.ullTimestamp / 1000000000ULL);
      pcap_header.ts.tv_usec = (long)(((uint64_t)ptOldestFrame->tHeader.ullTimestamp - (uint64_t)pcap_header.ts.tv_sec *1000000000ULL) / 1000);
    }

    /* Count the packet. */
    pPriv->ulReceivedCount++;

    /* build pcap frame with 4-byte header and frame payload */
    memcpy(pPriv->abFrameBuf, &ptOldestFrame->tHeader, sizeof(ptOldestFrame->tHeader.ulHeader));
    memcpy(pPriv->abFrameBuf + 4, &ptOldestFrame->abData, ulFrameSizeOrig);


    usPort = (ptOldestFrame->tHeader.ulHeader & NETANA_FRAME_HEADER_PORT_MSK) >> NETANA_FRAME_HEADER_PORT_SRT;
    ulFrameSize = ulFrameSizeOrig + sizeof(ptOldestFrame->tHeader.ulHeader);

    pcap_header.caplen = ulFrameSize;
    pcap_header.len = ulFrameSize;

    /* consistency check for frame sorting */
    if (ptOldestFrame->tHeader.ullTimestamp < pPriv->llLastSortedFrame)
    {
      /* this should never happen as sorted frames cannot have smaller timestamps */
      pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "warning: frame order mismatch\n");
      assert(0);
    }
    else
    {
      pPriv->llLastSortedFrame = ptOldestFrame->tHeader.ullTimestamp;

      /* drop frame if overflow is present (maybe due to timestamp scrambling between ports, where one port generated an overflow while other ports yet have received newer frames) */
      ulFrameType = (ptOldestFrame->tHeader.ulHeader & NETANA_FRAME_HEADER_TYPE_MSK) >> NETANA_FRAME_HEADER_TYPE_SRT;
      ulStateType = (ptOldestFrame->tHeader.ulHeader & NETANA_FRAME_HEADER_OVERFLOW_STATE_MSK) >> NETANA_FRAME_HEADER_OVERFLOW_STATE_SRT;
      ulVersion = (ptOldestFrame->tHeader.ulHeader & NETANA_FRAME_HEADER_VERSION_MSK) >> NETANA_FRAME_HEADER_VERSION_SRT;
      /* if this is a recovery frame, enable sorter again */
      if ((ulFrameType == NETANA_FRAME_HEADER_TYPE_VAL_FIFO_STATE) && (ulStateType == NETANA_FRAME_HEADER_OVERFLOW_STATE_VAL_END) && (ulVersion == 2))
      {
        pPriv->fSorterDropActive = SORTER_NO_DROP;
      }

      if (pPriv->fSorterDropActive == SORTER_NO_DROP)
      {
        if (ulFrameType != NETANA_FRAME_HEADER_TYPE_VAL_TIMETICK)
        {
          /* Call the user supplied callback function */
          pfnCallback(pbUser, &pcap_header, pPriv->abFrameBuf);
        }
      }
      else
      {
        /* drop frame */
        pthread_mutex_lock(&pPriv->tGetOldestFrameLock);
        pPriv->ulDropCount++;
        pthread_mutex_unlock(&pPriv->tGetOldestFrameLock);
      }

      /* if this is a drop frame diable sorter for next frame */
      if ((ulFrameType == NETANA_FRAME_HEADER_TYPE_VAL_FIFO_STATE) && (ulStateType == NETANA_FRAME_HEADER_OVERFLOW_STATE_VAL_START) && (ulVersion == 2))
      {
        pPriv->fSorterDropActive = SORTER_DROP;
      }

      pthread_mutex_lock(&pPriv->tGetOldestFrameLock);
      lSizeInQueue = ulFrameSizeOrig + sizeof(NETANA_ETH_FRAME_T);
      ChangeSizeOfRxQueue(pPriv, iSmallest, -lSizeInQueue);
      TAILQ_REMOVE(&(pPriv->avRxPorts[iSmallest].tFrameList), ptOldestFrame, entries);
      free(ptOldestFrame);
      pthread_mutex_unlock(&pPriv->tGetOldestFrameLock);
    }

  }

  return iFound;
}


void StopCapture(pcap_t* ptPcap)
{
  struct NETANA_PRIVATE_T* pPriv = ptPcap->priv;

  pPriv->iRecoverFromCaptureError = 0;

	netana_stop_capture(pPriv->hDevice);

#ifdef NETANA_SYNC
  /* cleanup syncthread */
  pPriv->tSyncConfig.fRunning = 0;
  pthread_cancel(pPriv->tSyncConfig.hSyncThread);
  pthread_join(pPriv->tSyncConfig.hSyncThread, NULL);
#endif

	netana_close_device(pPriv->hDevice);

  pthread_mutex_destroy(&pPriv->tGetOldestFrameLock);
}


static int GetStats(pcap_t *pPcapGlob, struct pcap_stat *ptStats) 
{
  struct NETANA_PRIVATE_T *pPriv = pPcapGlob->priv;
  
  ptStats->ps_drop = pPriv->ulDropCount;
  ptStats->ps_recv = pPriv->ulReceivedCount;

  return 0;
}




/*
 *  private functions
 */

#ifdef NETANA_SYNC
void* SyncThreadFunction(void* pvSyncParam)
{
  pcap_t*                   pPcapGlob = pvSyncParam;
  struct NETANA_PRIVATE_T*  pPriv = pPcapGlob->priv;
  int64_t                   llInterval = 0;
  uint64_t                  ullReferenceTime = 0;
  int32_t                   lSec = 0;
  int32_t                   lNSec = 0;
  struct timespec           tInterval = {0};
  struct timespec           tIntervalRemain = {0};
  struct timespec           tCurrentTime = {0};

  while(pPriv->tSyncConfig.fRunning == 1)
  {
    /* convert ns to timestruct interval */
    llInterval = pPriv->tSyncConfig.llIntervall; // reload interval
    lSec = llInterval / 1000000000;
    lNSec = llInterval % 1000000000;
    tInterval.tv_sec = lSec;
    tInterval.tv_nsec = lNSec;

    /* get current exact time from linux and convert to ns for netanalyzer */
    clock_gettime(CLOCK_REALTIME,  &tCurrentTime);
    ullReferenceTime = tCurrentTime.tv_nsec + (int64_t)tCurrentTime.tv_sec * 1000 * 1000 * 1000;
    /* resync now */
    netana_resync_time(pPriv->hDevice, ullReferenceTime);

    /* we are done now we try to sleep for interval */
    tIntervalRemain.tv_nsec = 0;
    tIntervalRemain.tv_sec = 0;
    int lRet = -1;
    while (lRet == -1 && (tInterval.tv_nsec != 0 || tInterval.tv_sec != 0))
    {
      lRet = nanosleep(&tInterval, &tIntervalRemain);
      tInterval = tIntervalRemain;
    }
  }
  return NULL;
}
#endif


uint32_t RecoverFromCaptureError(pcap_t* pPcapGlob)
{
  struct NETANA_PRIVATE_T*  pPriv = pPcapGlob->priv;
  uint32_t ulCaptureState = 0;
  uint32_t ulCaptureError = 0;
  uint32_t ulCaptureMode = NETANA_CAPTUREMODE_DATA;
  uint32_t ulRes;

  ulRes = netana_get_state(pPriv->hDevice, &ulCaptureState, &ulCaptureError);
  if (ulRes != NETANA_NO_ERROR)
  {
    pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "fatal error, during capture recover, netana_get_state failed (0x%08x)\n", ulRes);
    return -1;
  }

  if(ulCaptureState != NETANA_CAPTURE_STATE_OFF)
  {
    netana_stop_capture(pPriv->hDevice);
  }

  ulRes = netana_reftime_cfg(pPriv->hDevice, NETANA_MBX_CMD_SET_REFTIME_CFG_FREERUN);
  if(ulRes != NETANA_NO_ERROR)
  {
    pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "fatal error, during capture recover, netana_reftime_cfg failed (0x%08x)\n", ulRes);
    return -1;
  }

  ulRes = netana_clear_counter_cfg(pPriv->hDevice, NETANA_MBX_CMD_SET_CLEARCOUNTER_CFG_NO_CLEAR);
  if(ulRes != NETANA_NO_ERROR)
  {
    pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "fatal error, during capture recover, netana_clear_counter_cfg failed (0x%08x)\n", ulRes);
    return -1;
  }

  netana_timetick_ctrl(pPriv->hDevice, 1000);
  if(ulRes != NETANA_NO_ERROR)
  {
    pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "fatal error, during capture recover, netana_timetick_ctrl failed (0x%08x)\n", ulRes);
    return -1;
  }         

  ulRes = netana_start_capture(pPriv->hDevice,
                                0,
                                0xF,
                                NETANA_MACMODE_ETHERNET,
                                0,
                                StatusCallback,
                                DataCallback,
                                pPcapGlob);
  if(ulRes != NETANA_NO_ERROR)
  {
    pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "fatal error, during capture recover, netana_start_capture failed (0x%08x)\n", ulRes);
    return -1;
  }

  ulRes = netana_reftime_cfg(pPriv->hDevice, NETANA_MBX_CMD_SET_REFTIME_CFG_ONCE_AT_START);
  if(ulRes != NETANA_NO_ERROR)
  {
    pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "fatal error, during capture recover, netana_reftime_cfg failed (0x%08x)\n", ulRes);
    return -1;
  }

  ulRes = netana_clear_counter_cfg(pPriv->hDevice, NETANA_MBX_CMD_SET_CLEARCOUNTER_CFG_CLEAR_AT_RESTART);
  if(ulRes != NETANA_NO_ERROR)
  {
    pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "fatal error, during capture recover, netana_clear_counter_cfg failed (0x%08x)\n", ulRes);
    return -1;
  }

  return 0;
}


void ChangeSizeOfRxQueue(struct NETANA_PRIVATE_T* pPriv, uint32_t ulIdx, int32_t lSizeChange)
{
  if (lSizeChange > 0)
    pPriv->avRxPorts[ulIdx].tSize.lEntries += 1;
  else if (lSizeChange < 0)
    pPriv->avRxPorts[ulIdx].tSize.lEntries -= 1;
  pPriv->avRxPorts[ulIdx].tSize.ullSizeOnHeap += lSizeChange;
}


void InsertFrameInQueue(struct NETANA_PRIVATE_T* pPriv, uint32_t ulPort, NETANA_FRAME_HEADER_T* ptFrame, uint32_t ulFrameLen)
{
  NETANA_ETH_FRAME_T* ptCpyFrame = NULL;

  /* first copy only valid data to temp buffer, then insert it into the list */
  ptCpyFrame = (NETANA_ETH_FRAME_T*)malloc(sizeof(NETANA_ETH_FRAME_T) + ulFrameLen);
  if (ptCpyFrame == NULL)
  {
    /* no free memory available */
    assert(0);
    pPriv->iCaptureErrorPresent = 1;
  }
  else
  {
    memcpy(&ptCpyFrame->tHeader, ptFrame, sizeof(NETANA_FRAME_HEADER_T) + ulFrameLen);

    pthread_mutex_lock(&pPriv->tGetOldestFrameLock);
    ChangeSizeOfRxQueue(pPriv, ulPort, sizeof(NETANA_ETH_FRAME_T) + ulFrameLen);
    TAILQ_INSERT_HEAD(&(pPriv->avRxPorts[ulPort].tFrameList), ptCpyFrame, entries);
    pthread_mutex_unlock(&pPriv->tGetOldestFrameLock);
  }
}


unsigned long long GetUsedMemoryOfRxQueues(struct NETANA_PRIVATE_T* pPriv)
{
  uint64_t ullRes = 0;
  int iIdx = 0;

  for (iIdx = 0; iIdx < NUMBER_OF_RX_PORTS; iIdx++)
  {
    ullRes +=  pPriv->avRxPorts[iIdx].tSize.ullSizeOnHeap;
  }

  return ullRes;
}


void DataCallback(void* pvBuffer, uint32_t ulDataSize, void* pvUser)
{
  pcap_t*                   pPcapGlob = pvUser;
  struct NETANA_PRIVATE_T*  pPriv = pPcapGlob->priv;
  uint8_t*                  pbBuffer   = (uint8_t*)pvBuffer;
  uint32_t                  ulOffset   = 0;

  while (ulOffset < ulDataSize)
  {
    uint32_t            ulFrameLen = 0;
    uint32_t            ulFrameType = 0;
    uint32_t            ulPort = 0;
    NETANA_FRAME_HEADER_T* ptFrame = (NETANA_FRAME_HEADER_T*)(pbBuffer + ulOffset);

    ulFrameLen = (ptFrame->ulHeader & NETANA_FRAME_HEADER_LENGTH_MSK) >> NETANA_FRAME_HEADER_LENGTH_SRT;
    ulFrameType = (ptFrame->ulHeader & NETANA_FRAME_HEADER_TYPE_MSK) >> NETANA_FRAME_HEADER_TYPE_SRT;

    /* sort in, ports0..3 and gpio0..3 */
    ulPort = (ptFrame->ulHeader & NETANA_FRAME_HEADER_PORT_MSK) >> NETANA_FRAME_HEADER_PORT_SRT;
    if ((ptFrame->ulHeader & NETANA_FRAME_HEADER_GPIOEVT_MSK) >> NETANA_FRAME_HEADER_GPIOEVT_SRT != 00)
      ulPort += 4;

    /* for time tick pseudo frames we need a separate rx queue */
    if (ulFrameType == NETANA_FRAME_HEADER_TYPE_VAL_TIMETICK)
    {
      ulPort = RXPORT_TIMETICKFRAMES;
    }

    pthread_mutex_lock(&pPriv->tGetOldestFrameLock);

    /* update newest time if this frames time is newer than other frames (at this point different times from different ports may be mixed in time) */
    if (((int64_t)ptFrame->ullTimestamp) > pPriv->llNewestFrameTime)
      pPriv->llNewestFrameTime = ptFrame->ullTimestamp;

    pPriv->ullCurrentMemOfRxQueues = GetUsedMemoryOfRxQueues(pPriv);

    pthread_mutex_unlock(&pPriv->tGetOldestFrameLock);

    /* if application overflow situation was present, reset it immediately when the first frame from firmware arrives, as it has been recovered */
    if (pPriv->ulAppOverflowActive == 1)
    {
      NETANA_FRAME_HEADER_T tFifoOverflowFrame;

      tFifoOverflowFrame.ulHeader = (NETANA_FRAME_HEADER_TYPE_VAL_FIFO_STATE << NETANA_FRAME_HEADER_TYPE_SRT) |
        (0 << NETANA_FRAME_HEADER_PORT_SRT) |
        (2 << NETANA_FRAME_HEADER_VERSION_SRT) |
        (NETANA_FRAME_HEADER_OVERFLOW_STATE_VAL_END << NETANA_FRAME_HEADER_OVERFLOW_STATE_SRT) |
        (pPriv->ulAppOverflowSrc << NETANA_FRAME_HEADER_OVERFLOW_SRC_SRT);
      tFifoOverflowFrame.ullTimestamp = ptFrame->ullTimestamp;

      /* generate fifo overflow pseudo-frame */
      InsertFrameInQueue(pPriv, RXPORT_PSEUDOFRAMES, &tFifoOverflowFrame, 0);

      pPriv->ulAppOverflowActive = 0;
    }

    /* check limits of queue */
    if ((pPriv->ullCurrentMemOfRxQueues > pPriv->ullMaxQueueMemOverflow) &&
        (pPriv->fOverflowActive == 0))
    {
      pPriv->fOverflowActive = 1;

      NETANA_FRAME_HEADER_T tFifoOverflowFrame;

      tFifoOverflowFrame.ulHeader = (NETANA_FRAME_HEADER_TYPE_VAL_FIFO_STATE << NETANA_FRAME_HEADER_TYPE_SRT) |
        (ulPort << NETANA_FRAME_HEADER_PORT_SRT) |
        (2 << NETANA_FRAME_HEADER_VERSION_SRT) |
        (NETANA_FRAME_HEADER_OVERFLOW_STATE_VAL_START << NETANA_FRAME_HEADER_OVERFLOW_STATE_SRT) |
        (NETANA_FRAME_HEADER_OVERFLOW_SRC_VAL_BACKEND << NETANA_FRAME_HEADER_OVERFLOW_SRC_SRT);
      tFifoOverflowFrame.ullTimestamp = ptFrame->ullTimestamp;

      /* generate fifo overflow pseudo-frame */
      InsertFrameInQueue(pPriv, RXPORT_PSEUDOFRAMES, &tFifoOverflowFrame, 0);
    }

    /* check if overflow condition ends */
    if ((pPriv->ullCurrentMemOfRxQueues < pPriv->ullMaxQueueMemRecovery) &&
        (pPriv->fOverflowActive == 1))
    {
      NETANA_FRAME_HEADER_T tFifoOverflowFrame;
      tFifoOverflowFrame.ulHeader = (NETANA_FRAME_HEADER_TYPE_VAL_FIFO_STATE << NETANA_FRAME_HEADER_TYPE_SRT) |
        (ulPort << NETANA_FRAME_HEADER_PORT_SRT) |
        (2 << NETANA_FRAME_HEADER_VERSION_SRT) |
        (NETANA_FRAME_HEADER_OVERFLOW_STATE_VAL_END << NETANA_FRAME_HEADER_OVERFLOW_STATE_SRT) |
        (NETANA_FRAME_HEADER_OVERFLOW_SRC_VAL_BACKEND << NETANA_FRAME_HEADER_OVERFLOW_SRC_SRT);
      tFifoOverflowFrame.ullTimestamp = ptFrame->ullTimestamp;

      /* generate fifo overflow pseudo-frame */
      InsertFrameInQueue(pPriv, RXPORT_PSEUDOFRAMES, &tFifoOverflowFrame, 0);

      pPriv->fOverflowActive = 0;
    }

    if (pPriv->fOverflowActive == 0)
    {
      InsertFrameInQueue(pPriv, ulPort, ptFrame, ulFrameLen);
    }
    else if (ulPort != RXPORT_TIMETICKFRAMES) /* the drop counter should not contain the time tick pseudo frames */
    {
      pthread_mutex_lock(&pPriv->tGetOldestFrameLock);
      pPriv->ulDropCount++;
      pthread_mutex_unlock(&pPriv->tGetOldestFrameLock);
    }

    /* Adjust Offset to next DWORD aligned address */
    ulOffset += sizeof(NETANA_FRAME_HEADER_T) + ulFrameLen;
    while (ulOffset % 4)
      ++ulOffset;

  }
}


void InjectFifoOverflow(struct NETANA_PRIVATE_T* pPriv, uint32_t ulOverflowSrc)
{
  NETANA_FRAME_HEADER_T tFifoOverflowFrame;

  if (pPriv->ulAppOverflowActive == 1)
    return;

  tFifoOverflowFrame.ulHeader = (NETANA_FRAME_HEADER_TYPE_VAL_FIFO_STATE << NETANA_FRAME_HEADER_TYPE_SRT) |
    (0 << NETANA_FRAME_HEADER_PORT_SRT) |
    (2 << NETANA_FRAME_HEADER_VERSION_SRT) |
    (NETANA_FRAME_HEADER_OVERFLOW_STATE_VAL_START << NETANA_FRAME_HEADER_OVERFLOW_STATE_SRT) |
    (ulOverflowSrc << NETANA_FRAME_HEADER_OVERFLOW_SRC_SRT);
  tFifoOverflowFrame.ullTimestamp = pPriv->llNewestFrameTime;

  /* generate fifo overflow pseudo-frame */
  InsertFrameInQueue(pPriv, RXPORT_PSEUDOFRAMES, &tFifoOverflowFrame, 0);

  pPriv->ulAppOverflowActive = 1;
  pPriv->ulAppOverflowSrc = ulOverflowSrc;
}


void StatusCallback(uint32_t ulCaptureState, uint32_t ulCaptureError, void* pvUser)
{
  pcap_t*                   pPcapGlob = pvUser;
  struct NETANA_PRIVATE_T*  pPriv = pPcapGlob->priv;

  switch(ulCaptureState)
  {
    case NETANA_CAPTURE_STATE_STOP_PENDING:
      if (ulCaptureError != NETANA_CAPTURE_ERROR_STOP_TRIGGER) {
        uint32_t ulErrorSrc = -1;
        /* an unexpected capture error occured, report it */
        pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "warning: a capture error occured, netANALYZER error code: 0x%08x, data dropped\n", ulCaptureError);

        if (ulCaptureError == NETANA_CAPTURE_ERROR_NO_HOSTBUFFER) {
          ulErrorSrc = NETANA_FRAME_HEADER_OVERFLOW_SRC_VAL_HOSTBUF;
        } else if (ulCaptureError == NETANA_CAPTURE_ERROR_NO_INTRAMBUFFER) {
          ulErrorSrc = NETANA_FRAME_HEADER_OVERFLOW_SRC_VAL_INTRAMBUF;
        } else if (ulCaptureError == NETANA_CAPTURE_ERROR_URX_OVERFLOW) {
          ulErrorSrc = NETANA_FRAME_HEADER_OVERFLOW_SRC_VAL_URX;
        }

        if (ulErrorSrc != -1)
        {
          InjectFifoOverflow(pPriv, ulErrorSrc);
          pPriv->iRecoverFromCaptureError = 1;
        }
        else
        {
          pcap_snprintf(pPcapGlob->errbuf, PCAP_ERRBUF_SIZE, "unrecoverable error, capture stopped automatically\n");
          pPriv->iCaptureErrorPresent = 1;
        }
      }
      break;

    default:
        /* no special action requiered for other cases */
      break;
  }
}



/*
 * special libpcap functions
 */

#ifdef NETANA_ONLY
/*
 * This libpcap build supports only netANALYZER cards, not regular network
 * interfaces.
 */

/*
 * There are no regular interfaces, just netANALYZER interfaces.
 */
int
pcap_platform_finddevs(pcap_if_list_t *devlistp, char *pbErrBuf)
{
  return (0);
}

/*
 * Attempts to open
 a regular interface fail.
 */
pcap_t *
pcap_create_interface(const char *device, char *pbErrBuf)
{
  pcap_snprintf(pbErrBuf, PCAP_ERRBUF_SIZE,
                "This version of libpcap only supports netANALYZER cards");
  return (NULL);
}

/*
 * Libpcap version string.
 */
const char *
pcap_lib_version(void)
{
  return (PCAP_VERSION_STRING " (netANALYZER-only)");
}
#endif



