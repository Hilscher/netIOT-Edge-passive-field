/*
 * pcap-netanalyzer.c: Packet capture interface for Hilscher netANALYZER devices
 *
 * The functionality of this code attempts to mimic that of pcap-linux as much
 * as possible.  This requires libnetana to run.
 *
 * Author: Holger Pfrommer (hpfrommer@hilscher.com)
 */

pcap_t* NetanalyzerCreate(const char* pbDevice, char* pbEBuf, int* piIsOurs);
int NetanalyzerFindalldevs(pcap_if_list_t* ptDevList, char* pbErrBuf);
